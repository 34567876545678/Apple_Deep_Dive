# Apple Product Deep Dive Explorer

An interactive, premium dashboard exploring the architectural performance, pricing strategies, ecological footprint, and consumer sentiment of Apple hardware designs.

## Features

- **Apple Hardware Architectures**: Select and explore deep-dives for major Apple products.
- **Architectural Dimensions**: Analyze key dimensions:
  - Product Quality & Performance
  - Environmental Impact & Sustainability
  - Pricing & Margin Dynamics
  - Social Sentiment & Consumer Feedback
- **Polished Presentation**: Designed with custom typography, clean animated transitions, intuitive accordions, and a premium Apple-inspired aesthetic.


## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   npm run dev
   ```

3. Build for production:
   ```bash
   npm run build
   ```
