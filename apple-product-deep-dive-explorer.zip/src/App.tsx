import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Smartphone,
  Laptop,
  Watch,
  Tablet,
  Eye,
  Cpu,
  Leaf,
  Coins,
  MessageSquare,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { appleProductsData, ProductDeepDive } from "./data";

export default function App() {
  const [selectedProduct, setSelectedProduct] = useState<ProductDeepDive>(
    appleProductsData[0]
  );

  // Expander collapse states matching st.expander
  const [expandQuality, setExpandQuality] = useState(true);
  const [expandEnv, setExpandEnv] = useState(true);
  const [expandPrice, setExpandPrice] = useState(true);
  const [expandSocial, setExpandSocial] = useState(true);

  // Icon mapping according to product category
  const getProductIcon = (category: string) => {
    switch (category) {
      case "Smartphones":
        return <Smartphone className="w-5 h-5 text-emerald-400" />;
      case "Laptops":
        return <Laptop className="w-5 h-5 text-indigo-400" />;
      case "Wearables":
        return <Watch className="w-5 h-5 text-orange-400" />;
      case "Tablets":
        return <Tablet className="w-5 h-5 text-sky-400" />;
      case "Spatial Computing":
        return <Eye className="w-5 h-5 text-fuchsia-400" />;
      default:
        return <Cpu className="w-5 h-5 text-slate-400" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f5f7] text-slate-850 flex flex-col justify-between">
      {/* Dynamic Background Aura */}
      <div className="absolute top-0 left-1/4 w-[400px] h-[400px] rounded-full bg-emerald-500/10 blur-[120px] pointer-events-none" />
      <div className="absolute top-1/3 right-1/4 w-[500px] h-[500px] rounded-full bg-indigo-500/10 blur-[150px] pointer-events-none" />

      {/* Main Structural Centered Body */}
      <div className="max-w-6xl w-full mx-auto px-6 py-8 md:py-12 z-10 flex-grow bg-[#ffffff] rounded-2xl md:rounded-3xl shadow-sm border border-slate-200/80 mt-4 md:mt-8 mb-8">
        {/* Visual Header Grid */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-slate-200 pb-8 mb-8 gap-6">
          <div>
            <h1 className="font-display font-bold text-4xl md:text-5xl tracking-tight text-[#000000] mb-2">
              APPLE DEEP DIVE
            </h1>
            <p className="text-[#074bca] text-sm md:text-base max-w-xl">
              Apple is famous for its minimalist, pristine product design and marketing. But beneath the surface of that sleek, recycled aluminum shell lies a complex world of hidden hardware metrics, manufacturing costs, and environmental impacts that Apple rarely highlights in its keynotes.
            </p>
          </div>


        </div>

        {/* Workspace Interactive Control Hub */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Navigation & Selection Block (Col-1) */}
          <div className="lg:col-span-1 flex flex-col gap-4">
            <h2 className="text-slate-500 font-mono text-xs tracking-wider uppercase mb-1 font-semibold">
              Select Architecture
            </h2>
            <div className="flex flex-col gap-2.5">
              {appleProductsData.map((prod) => {
                const isSelected = prod.name === selectedProduct.name;
                return (
                  <button
                    key={prod.name}
                    onClick={() => {
                      setSelectedProduct(prod);
                      // Reset expander panels to default open on hardware change
                      setExpandQuality(true);
                      setExpandEnv(true);
                      setExpandPrice(true);
                      setExpandSocial(true);
                    }}
                    className={`relative w-full text-left p-4 rounded-xl border transition-all duration-305 group flex items-center gap-3.5 ${
                      isSelected
                        ? "bg-slate-900 border-slate-900 text-white shadow-md shadow-slate-900/10"
                        : "bg-slate-50/50 border-slate-200 hover:border-slate-300 text-slate-700 hover:text-slate-900"
                    }`}
                  >
                    {/* Active selection dot left indicators */}
                    {isSelected && (
                      <motion.div
                        layoutId="activeIndicator"
                        className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-6 bg-emerald-400 rounded-r"
                      />
                    )}
                    <div className="flex-shrink-0">
                      {getProductIcon(prod.category)}
                    </div>
                    <div className="flex-grow">
                      <h4 className={`font-semibold text-sm tracking-tight transition-colors ${
                        isSelected ? "text-white" : "text-slate-800 group-hover:text-black"
                      }`}>
                        {prod.name}
                      </h4>
                    </div>
                  </button>
                );
              })}
            </div>


          </div>

          {/* Interactive Core Display Details Card (Col-2 to Col-4) */}
          <div className="lg:col-span-3 flex flex-col gap-6">
            
            {/* Top overview Banner with hardware stats */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl overflow-hidden shadow-sm relative">
              <div className="p-6 md:p-8 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-xs font-mono text-emerald-700 font-semibold">
                      Expected Price: {selectedProduct.priceStart}
                    </span>
                  </div>
                  <h3 className="font-display font-extrabold text-2xl md:text-3xl text-slate-900 tracking-tight leading-slug mb-1">
                    {selectedProduct.name}
                  </h3>
                  <p className="text-slate-500 text-sm italic font-sans animate-fade-in">
                    "{selectedProduct.tagline}"
                  </p>
                </div>


              </div>
            </div>

            {/* Grid display layout mimicking expandable st.expanders */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Expandable Section 1: Quality / Performance */}
              <div className="flex flex-col gap-4">
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                  <button
                    onClick={() => setExpandQuality(!expandQuality)}
                    className="w-full text-left px-5 py-4 border-b border-slate-200 bg-slate-50/50 hover:bg-slate-50 flex items-center justify-between transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <Cpu className="w-4.5 h-4.5 text-indigo-600" />
                      <span className="font-semibold text-sm tracking-tight text-slate-800">
                        Product Quality & Architecture
                      </span>
                    </div>
                    {expandQuality ? (
                      <ChevronUp className="w-4 h-4 text-slate-550" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-550" />
                    )}
                  </button>

                  <AnimatePresence initial={false}>
                    {expandQuality && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden bg-white"
                      >
                        <div className="p-5 flex flex-col gap-4">
                          {selectedProduct.quality.map((bullet, idx) => (
                            <div key={idx} className="flex gap-2.5 items-start">
                              <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-indigo-100 text-indigo-800 font-mono text-[10px] shrink-0 mt-0.5 border border-indigo-200/80">
                                {idx + 1}
                              </span>
                              <p className="text-xs text-slate-600 leading-relaxed font-sans">
                                {bullet}
                              </p>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Expandable Section 2: Environmental & Sustainability */}
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                  <button
                    onClick={() => setExpandEnv(!expandEnv)}
                    className="w-full text-left px-5 py-4 border-b border-slate-200 bg-slate-50/50 hover:bg-slate-50 flex items-center justify-between transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <Leaf className="w-4.5 h-4.5 text-emerald-600" />
                      <span className="font-semibold text-sm tracking-tight text-slate-800">
                        Environmental & Ecology
                      </span>
                    </div>
                    {expandEnv ? (
                      <ChevronUp className="w-4 h-4 text-slate-550" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-550" />
                    )}
                  </button>

                  <AnimatePresence initial={false}>
                    {expandEnv && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden bg-white"
                      >
                        <div className="p-5 flex flex-col gap-4">
                          {selectedProduct.environmental.map((bullet, idx) => (
                            <div key={idx} className="flex gap-2.5 items-start">
                              <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-mono text-[10px] shrink-0 mt-0.5 border border-emerald-200/80">
                                {idx + 1}
                              </span>
                              <p className="text-xs text-slate-600 leading-relaxed font-sans">
                                {bullet}
                              </p>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              {/* Column 2 Expandables */}
              <div className="flex flex-col gap-4">
                {/* Expandable Section 3: Price Mechanism */}
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                  <button
                    onClick={() => setExpandPrice(!expandPrice)}
                    className="w-full text-left px-5 py-4 border-b border-slate-200 bg-slate-50/50 hover:bg-slate-50 flex items-center justify-between transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <Coins className="w-4.5 h-4.5 text-orange-600" />
                      <span className="font-semibold text-sm tracking-tight text-slate-800">
                        Margin & Pricing Transparency
                      </span>
                    </div>
                    {expandPrice ? (
                      <ChevronUp className="w-4 h-4 text-slate-550" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-555" />
                    )}
                  </button>

                  <AnimatePresence initial={false}>
                    {expandPrice && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden bg-white"
                      >
                        <div className="p-5 flex flex-col gap-4">
                          {selectedProduct.pricing.map((bullet, idx) => (
                            <div key={idx} className="flex gap-2.5 items-start">
                              <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-orange-100 text-orange-800 font-mono text-[10px] shrink-0 mt-0.5 border border-orange-200/80">
                                {idx + 1}
                              </span>
                              <p className="text-xs text-slate-600 leading-relaxed font-sans">
                                {bullet}
                              </p>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Expandable Section 4: Social Media Sentiment */}
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                  <button
                    onClick={() => setExpandSocial(!expandSocial)}
                    className="w-full text-left px-5 py-4 border-b border-slate-200 bg-slate-50/50 hover:bg-slate-50 flex items-center justify-between transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <MessageSquare className="w-4.5 h-4.5 text-indigo-650" />
                      <span className="font-semibold text-sm tracking-tight text-slate-800">
                        Social Word-of-Mouth Matrix
                      </span>
                    </div>
                    {expandSocial ? (
                      <ChevronUp className="w-4 h-4 text-slate-550" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-550" />
                    )}
                  </button>

                  <AnimatePresence initial={false}>
                    {expandSocial && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden bg-white"
                      >
                        <div className="p-5 flex flex-col gap-4">
                          {selectedProduct.social.map((bullet, idx) => (
                            <div key={idx} className="flex gap-2.5 items-start">
                              <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-indigo-100 text-indigo-800 font-mono text-[10px] shrink-0 mt-0.5 border border-indigo-200/80">
                                {idx + 1}
                              </span>
                              <p className="text-xs text-slate-600 leading-relaxed font-sans">
                                {bullet}
                              </p>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>

            </div>



          </div>

        </div>
      </div>


    </div>
  );
}
